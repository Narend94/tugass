# Sistem-Perpustakaan-Sekolah
Nama Project ini adalah : CuyPerpus

CuyPerpus adalah sebuah aplikasi berbasis website yang memberikan pelayanan berupa sistem peminjaman dan pengelolaan buku perpustakaan.

website ini dibuat menggunakan framework bootstrap, javascript, php dan database mysql.

Fitur fitur yang terdapat didalam aplikasi ini : 
1. Memiliki 2 akses login, admin dan user/siswa .
2. Akses sebagai admin mendapatkan fasilitas berupa : 
  - insert, update dan delete data buku
  - mencari buku berdasarkan judul dan kategori
  - mengelola data siswa yang daftar pada aplikasi
  - mengelola setiap peminjaman buku
  - mengelola setiap pengembalian buku
  - menerapkan denda jika siswa/user terlambat mengembalikan buku sesuai jadwal yang ditentukan.
3. Akses sebagai siswa mendapatkan fasilitas berupa : 
  - dapat melihat isi seluruh buku yang ada dalam perpustakaan dan terdapat fitur filter buku berdasarkan kategori.
  - meminjam buku 
  - mengembalikan buku
  - membayar denda


Created by Mangandaralam Sakti - Student At SMKN 1 Jakarta
